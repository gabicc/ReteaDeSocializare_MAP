package social_network.repo;

import social_network.domain.*;
import social_network.events.*;
import social_network.exceptions.ExistingFriendshipException;
import social_network.exceptions.FriendshipDoesntExist;
import social_network.exceptions.UserDoesntExistException;
import social_network.exceptions.ExistingUserException;
import social_network.observable.SocialObservable;

import java.util.*;

public class Network extends SocialObservable {
    private List<User> users = new ArrayList<User>();
    private Map<Long, Set<Long>> friendships = new HashMap<Long, Set<Long>>();
    private List<Message> messages = new ArrayList<Message>();
    private ValidatorUser validatorUser = new ValidatorUser(this);
    private ValidatorFriendship validatorFriendship = new ValidatorFriendship(this);
    private ValidatorMessage validatorMessage = new ValidatorMessage(this);

    public Network() {}

    public List<User> getAllUsers() {
        return users;
    }

    public Map<Long, Set<Long>> getAllFriendships() {
        return friendships;
    }

    public List<Message> getAllMessages() {
        return messages;
    }

    public void addUser(User u) {
        validatorUser.validate(u);

        users.add(u);
        notify(new UserAddEvent(u));
    }

    public User removeUser(long id) {
        // This method verifies if a user exists and it deletes it if yes
        for(User us: users) {
            if(us.getId().equals(id)) {
                Set<Long> friends =  friendships.getOrDefault(us.getId(), new HashSet<>());
                Set<Long> newFriendsList = new HashSet<>();
                newFriendsList.addAll(friends);
                for(Long friendID: newFriendsList) {
                    removeFriendship(id, friendID);
                }

                List<Message> newMessage = new ArrayList<>();
                for(Message m: newMessage) {
                    if(m.getFromId().equals(us.getId()))
                        messages.remove(m);
                }

                users.remove(us);
                notify(new UserRemoveEvent(us));
                return us;
            }
        }
        throw new UserDoesntExistException("This user cannot be removed due to the lack of atoms that it has(it doesnt exist)");
    }

    public void updateUser(User u) {
        // nu mai stiu ce sa pun aici
        int gasit = 0;
        for(User us: users) {
            if(us.getId().equals(u.getId())){
                gasit = 1;
                us.setFirtName(u.getFirstName());
                us.setLastname(u.getLastname());
                notify(new UserUpdateEvent(u));
            }
        }
        if(gasit == 0)
            throw new UserDoesntExistException("User cannot be updated because it's not in the list");
    }

    //getall, crud firendship, message crud
    public void addFriendship(long id1, long id2){
        // nu mai stiu ce sa pun
        Set<Long> a = friendships.getOrDefault(id1, new HashSet<Long>());
        Friendship f = new Friendship(id1, id2);
        validatorFriendship.validate(f);
        if(a.contains(id2))
            System.out.println("Friendship between user with id: " + id1 + " and user with id: " + id2 + " already exists");
        a.add(id2);
        friendships.put(id1, a);

        Set<Long> b = friendships.getOrDefault(id2, new HashSet<Long>());
        if(b.contains(id1))
            System.out.println("Friendship between user with id: " + id1 + " and user with id: " + id2 + " already exists");
        b.add(id1);
        friendships.put(id2, b);

        notify(new FriendshipAddEvent(f));
    }

    public void removeFriendship(long id1, long id2){
        // mi-e lene
        Set<Long> a = friendships.getOrDefault(id1, new HashSet<Long>());
        if(!a.contains(id2)){
            throw new FriendshipDoesntExist("Friendship doesnt exist");
        }
        a.remove(id2);

        Set<Long> b = friendships.getOrDefault(id2, new HashSet<Long>());
        if(!b.contains(id1)){
            throw new FriendshipDoesntExist("Friendship doesnt exist");
        }
        b.remove(id1);

        notify(new FriendshipRemoveEvent(new Friendship(id1, id2)));
    }

    public void addMessage(Message m) {
        validatorMessage.validate(m);
        messages.add(m);
        notify(new MessageAddEvent(m));
    }

    public void removeMessages(Message messageToRemove) {
        // cam atat
        boolean removed = messages.removeIf(message ->
                message.getId().equals(messageToRemove.getId()));

        if (!removed) {
            throw new IllegalArgumentException(
                    "Message with id " + messageToRemove.getId() + " does not exist.");
        }

        notify(new MessageRemoveEvent(messageToRemove));
    }

    public List<Message> userAllSentMessages(long id){
        List<Message> ms = new ArrayList<Message>();
        for(Message m: messages) {
            if(m.getFromId() == id) {
                ms.add(m);
            }
        }
        return ms;
    }

    public List<Message> userAllReceivedMessages(long id){
        List<Message> ms = new ArrayList<Message>();
        for(Message m: messages) {
            if(m.getToId() == id) {
                ms.add(m);
            }
        }
        return ms;
    }

    public Set<Long> userAllFriendsIds(long id) {
        return friendships.getOrDefault(id, new HashSet<Long>());
    }

    public Set<Long> getUserCommunity(long id) {
        //long V = friendships.size();
        Map<Long, Boolean> vizited = new HashMap<Long, Boolean>();
        for(User u: users) {
            vizited.put(u.getId(), false);
        }

        Set<Long> res = new HashSet<Long>();

        Queue<Long> q = new LinkedList<>();
        q.add(id);
        while(!q.isEmpty()) {
            long current = q.poll();
            res.add(current);
            vizited.put(current, true);
            Set<Long> friends = friendships.getOrDefault(current, new HashSet<Long>());
            for(Long i: friends) {
                if(vizited.get(i) == false) {
                    vizited.put(i, true);
                    q.add(i);
                }
            }
        }
        return res;
    }

    private Long firstNotVisited(Map<Long, Boolean> visited) {
        for(Map.Entry<Long, Boolean> entry: visited.entrySet()) {
            if(!entry.getValue()) {
                return entry.getKey();
            }
        }
        return null;
    }

    public List<Set<Long>> getAllCommunities() {
        // nu mai am chef
        Map<Long, Boolean> visited = new HashMap<Long, Boolean>();
        List<Set<Long>> rezList = new ArrayList<>();
        for(User u: users) {
            visited.put(u.getId(), false);
        }

        Queue<Long> q = new LinkedList<>();
        Long first = firstNotVisited(visited);
        while(first != null) {
            Set<Long> res = new HashSet<Long>();
            q.add(first);
            while (!q.isEmpty()) {
                long current = q.poll();
                res.add(current);
                visited.put(current, true);
                Set<Long> friends = friendships.getOrDefault(current, new HashSet<Long>());
                for (Long i : friends) {
                    if (visited.get(i) == false) {
                        visited.put(i, true);
                        q.add(i);
                    }
                }
            }
            rezList.add(res);
            first = firstNotVisited(visited);
        }
        return rezList;
    }

    public Integer numberOfCommunities() {
        List<Set<Long>> rezList = getAllCommunities();
        return rezList.size();
    }

    public Set<Long> mostSociableCommunity() {
        List<Set<Long>> rezList = getAllCommunities();
        long maxx = 0;
        Set<Long> finn = new HashSet<>();
        for(Set<Long> res: rezList) {
            if(res.size()>maxx) {
                maxx = res.size();
                finn = res;
            }
        }
        return finn;
    }
}
