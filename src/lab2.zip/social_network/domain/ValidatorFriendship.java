package social_network.domain;

import social_network.repo.Network;

import java.util.ArrayList;
import java.util.HashSet;
/**
 * ValidatorFriendship class is responsible for validating Friendship entities.
 * It checks if the friendship IDs are not null, if they are not the same, and if the friendship already exists in the network.
 */
public class ValidatorFriendship extends Validator<Friendship> {
    public ValidatorFriendship(Network network) {
        super(network);
    }

    @Override
    public void validate(Friendship entity) {
        if (entity.getId1() == null || entity.getId2() == null) {
            throw new IllegalArgumentException("Friendship ID cannot be null");
        }
        if (entity.getId1().equals(entity.getId2())) {
            throw new IllegalArgumentException("Friendship cannot be between the same user");
        }
        for (long friendshipId : network.getAllFriendships().getOrDefault(entity.getId1(), new HashSet<>())) {
            if ((friendshipId == entity.getId1() && friendshipId == entity.getId2()) ||
                    (friendshipId == entity.getId2() && friendshipId == entity.getId1())) {
                throw new IllegalArgumentException("Friendship between users " + entity.getId1() + " and " + entity.getId2() + " already exists");
            }
        }
    }
}
