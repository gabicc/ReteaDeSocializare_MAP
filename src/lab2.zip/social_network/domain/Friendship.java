package social_network.domain;
/*
* This class has 2 parameters and it forms a friendship between users with id1 and id2
* */
public class Friendship {
    private long id1;
    private long id2;

    public Friendship(long id1, long id2) {
        this.id1 = id1;
        this.id2 = id2;
    }

    public Long getId1() {
        return id1;
    }

    public Long getId2() {
        return id2;
    }

    @Override
    public String toString() {
        return "Friendship{" +
                "id1=" + id1 +
                ", id2=" + id2 +
                '}';
    }
}
